from django.apps import AppConfig


class MailConfig(AppConfig):
    name = 'mail'
