# Cherries



This page is about cherries and not any other fruit.  Cherries are a type of stone fruit, like:



- Apricots

- Peaches

- Plums