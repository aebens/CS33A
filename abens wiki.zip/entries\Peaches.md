# Peaches

One of the most common stone fruits, peaches are known in most cultures.  It is related to:

- Apricots

- Plums

- Cherries