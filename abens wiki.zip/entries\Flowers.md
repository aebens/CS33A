# Flowers

There are many types of flowers, with some of the major types given below.

## Daisies

Most people have seen these before.

## Sunflowers

Usually yellow in color, they can also be **red**.