This has two types of lists.

1. Ordered
2. Lists
3. To
4. Compare

But also

- Unordered
- Lists
- To
- Ensure
- Compliance!