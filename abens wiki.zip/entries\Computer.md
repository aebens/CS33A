Computers have been with us for a very long time.  They include many brands:
- Apple
- Dell
- Lenovo